"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseAgent = void 0;
const SecurityEnforcer_1 = require("../security/SecurityEnforcer");
const logger_1 = require("../../services/logger");
class BaseAgent {
    constructor(aiProvider) {
        this.aiProvider = aiProvider;
        // The tools this specific agent is allowed to use.
        this.tools = new Map();
    }
    registerTool(tool) {
        this.tools.set(tool.name, tool);
    }
    /**
     * Executes a highly specific task using only the tools available to this agent.
     */
    async executeTask(task, _context) {
        logger_1.logger.info(`[${this.name}] Received task: ${task.description}`);
        // Example logic showing how an agent executes a tool securely
        if (task.payload && task.payload.toolName) {
            const tool = this.tools.get(task.payload.toolName);
            if (!tool) {
                return { taskId: task.id, success: false, error: 'Tool not found in agent sandbox.' };
            }
            try {
                const data = await SecurityEnforcer_1.SecurityEnforcer.executeToolSecurely(this.name, tool, task.payload.args, _context);
                return { taskId: task.id, success: true, data };
            }
            catch (err) {
                return { taskId: task.id, success: false, error: err.message };
            }
        }
        return {
            taskId: task.id,
            success: true,
            data: { message: `Simulated execution of ${task.description} by ${this.name}` }
        };
    }
}
exports.BaseAgent = BaseAgent;
