"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentOrchestrator = void 0;
const TaskPlanner_1 = require("./TaskPlanner");
const ExecutionEngine_1 = require("./ExecutionEngine");
const logger_1 = require("../../services/logger");
class AgentOrchestrator {
    constructor(provider, taskManager) {
        this.taskManager = taskManager;
        this.planner = new TaskPlanner_1.TaskPlanner(provider);
        this.engine = new ExecutionEngine_1.ExecutionEngine(this.taskManager);
    }
    async processIntent(userInput) {
        logger_1.logger.info(`[AgentOrchestrator] Received intent: ${userInput}`);
        try {
            // 1. Planning Phase
            const plan = await this.planner.planTask(userInput);
            logger_1.logger.info(`[AgentOrchestrator] Generated plan: ${plan.id}`);
            // 2. Register with Task Manager
            this.taskManager.register(plan);
            // 3. Execution Phase
            await this.engine.execute(plan);
        }
        catch (err) {
            logger_1.logger.error(`[AgentOrchestrator] Failed to process intent`, err);
            // Fallback state update
            const errorState = 'ERROR';
            // In a real app we'd target the specific task ID, but here we broadcast globally
            if (this.taskManager.broadcastState) {
                this.taskManager.broadcastState(errorState);
            }
        }
    }
}
exports.AgentOrchestrator = AgentOrchestrator;
