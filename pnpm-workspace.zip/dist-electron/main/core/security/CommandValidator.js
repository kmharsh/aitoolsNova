"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommandValidator = void 0;
class CommandValidator {
    static validate(command) {
        const isAllowed = this.ALLOWLIST.some(regex => regex.test(command.trim()));
        if (!isAllowed) {
            throw new Error(`Security Exception: Command execution blocked by allowlist -> "${command}"`);
        }
    }
}
exports.CommandValidator = CommandValidator;
CommandValidator.ALLOWLIST = [
    /^npm\s+(run\s+)?(test|lint|build|dev)$/,
    /^yarn\s+(test|lint|build|dev)$/,
    /^pnpm\s+(test|lint|build|dev)$/,
    /^git\s+(status|diff|add\s+\.|commit\s+-m.*)$/
];
