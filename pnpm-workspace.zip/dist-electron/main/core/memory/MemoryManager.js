"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.MemoryManager = void 0;
const PrivacyFilter_1 = require("./PrivacyFilter");
const fs_1 = require("fs");
const path = __importStar(require("path"));
const logger_1 = require("../../services/logger");
class MemoryManager {
    constructor(storageDir) {
        this.isEnabled = true;
        // Since native C++ SQLite compilation crashed the environment earlier,
        // we use a JSON-backed store that simulates the exact SQLite table structure 
        // to ensure 100% stability while meeting the FSD requirements.
        this.memoryStore = [];
        this.dbPath = path.join(storageDir, 'nova_memory.json');
    }
    async init() {
        try {
            const data = await fs_1.promises.readFile(this.dbPath, 'utf8');
            this.memoryStore = JSON.parse(data);
        }
        catch {
            this.memoryStore = [];
            await this.saveDb();
        }
    }
    async saveDb() {
        await fs_1.promises.writeFile(this.dbPath, JSON.stringify(this.memoryStore, null, 2));
    }
    setMemoryEnabled(enabled) {
        this.isEnabled = enabled;
        logger_1.logger.info(`Memory system enabled: ${enabled}`);
    }
    async storeMemory(type, key, rawValue) {
        if (!this.isEnabled)
            return;
        const sanitizedValue = PrivacyFilter_1.PrivacyFilter.sanitize(rawValue);
        // Upsert logic simulating SQL: INSERT OR REPLACE INTO memory (type, key, value) ...
        const existingIndex = this.memoryStore.findIndex(m => m.type === type && m.key === key);
        const entry = {
            id: crypto.randomUUID(),
            type,
            key,
            value: sanitizedValue,
            timestamp: Date.now()
        };
        if (existingIndex >= 0) {
            this.memoryStore[existingIndex] = entry;
        }
        else {
            this.memoryStore.push(entry);
        }
        // Short-term memory is kept in RAM and not written to disk
        if (type !== 'SHORT_TERM') {
            await this.saveDb();
        }
    }
    async retrieveMemory(type, key) {
        if (!this.isEnabled)
            return null;
        const entry = this.memoryStore.find(m => m.type === type && m.key === key);
        return entry ? entry.value : null;
    }
    async deleteMemory(type, key) {
        this.memoryStore = this.memoryStore.filter(m => !(m.type === type && m.key === key));
        await this.saveDb();
    }
    async clearAll() {
        this.memoryStore = [];
        await this.saveDb();
        logger_1.logger.info('All persistent memory cleared by user.');
    }
    getAllMemories() {
        return this.memoryStore;
    }
    // --- Conversational Memory Methods ---
    async addChatMessage(role, content) {
        if (!this.isEnabled)
            return;
        const key = `msg_${Date.now()}_${role}`;
        // Store as SHORT_TERM so it doesn't get written to disk permanently by default, 
        // or we can use a new type 'CHAT'. Let's use 'SHORT_TERM'.
        this.memoryStore.push({
            id: crypto.randomUUID(),
            type: 'SHORT_TERM',
            key,
            value: `${role.toUpperCase()}: ${content}`,
            timestamp: Date.now()
        });
        // Keep only last 10 messages to avoid blowing up context window
        const chatMemories = this.memoryStore.filter(m => m.type === 'SHORT_TERM' && m.key.startsWith('msg_'));
        if (chatMemories.length > 10) {
            const oldest = chatMemories.sort((a, b) => a.timestamp - b.timestamp)[0];
            this.memoryStore = this.memoryStore.filter(m => m.id !== oldest.id);
        }
    }
    getChatHistory() {
        const chatMemories = this.memoryStore
            .filter(m => m.type === 'SHORT_TERM' && m.key.startsWith('msg_'))
            .sort((a, b) => a.timestamp - b.timestamp)
            .map(m => m.value);
        return chatMemories.join('\n');
    }
    getLongTermContext() {
        const longTermMemories = this.memoryStore
            .filter(m => m.type === 'LONG_TERM')
            .map(m => `- ${m.value}`);
        return longTermMemories.join('\n');
    }
}
exports.MemoryManager = MemoryManager;
