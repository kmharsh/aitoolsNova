"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModifyFilesTool = void 0;
const BaseTool_1 = require("../BaseTool");
const zod_1 = require("zod");
const fs = __importStar(require("fs"));
const PathValidator_1 = require("../../security/PathValidator");
class ModifyFilesTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'developer.modifyFiles';
        this.description = 'Modifies or creates source code files. Requires explicit user confirmation.';
        this.inputSchema = zod_1.z.object({
            filePath: zod_1.z.string().describe('Absolute path to the file to modify.'),
            newContent: zod_1.z.string().describe('The completely new content for the file.')
        });
        this.outputSchema = zod_1.z.any();
        this.riskLevel = 'HIGH';
        this.requiresPermission = true;
        this.timeoutMs = 30000;
    }
    async execute(input, _context) {
        try {
            PathValidator_1.pathValidator.validate(input.filePath);
        }
        catch (e) {
            throw new Error(`Access Denied: Path is protected or blocked.`);
        }
        try {
            await fs.promises.writeFile(input.filePath, input.newContent, 'utf8');
            return { success: true, message: `Successfully modified ${input.filePath}` };
        }
        catch (err) {
            throw new Error(`Failed to write file: ${err.message}`);
        }
    }
}
exports.ModifyFilesTool = ModifyFilesTool;
