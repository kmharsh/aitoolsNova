"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileDeleteTool = void 0;
const zod_1 = require("zod");
const BaseTool_1 = require("../BaseTool");
const fs_1 = require("fs");
const PathValidator_1 = require("../../security/PathValidator");
const InputSchema = zod_1.z.object({
    targetPath: zod_1.z.string().describe('The absolute or relative path to delete')
});
const OutputSchema = zod_1.z.object({
    success: zod_1.z.boolean(),
    message: zod_1.z.string()
});
class FileDeleteTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'filesystem.delete';
        this.description = 'Deletes a file or directory permanently.';
        this.inputSchema = InputSchema;
        this.outputSchema = OutputSchema;
        this.riskLevel = 'HIGH'; // CRITICAL: This is a high-risk operation
        this.requiresPermission = true; // Must force UI permission dialog
        this.timeoutMs = 10000;
    }
    async execute(input, context) {
        context.emitActivity(`Preparing to delete: ${input.targetPath}`);
        // Security check
        const resolvedPath = PathValidator_1.pathValidator.validate(input.targetPath);
        const stats = await fs_1.promises.stat(resolvedPath);
        if (stats.isDirectory()) {
            await fs_1.promises.rm(resolvedPath, { recursive: true, force: true });
        }
        else {
            await fs_1.promises.unlink(resolvedPath);
        }
        return {
            success: true,
            message: `Deleted ${resolvedPath}`
        };
    }
}
exports.FileDeleteTool = FileDeleteTool;
