"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
electron_1.contextBridge.exposeInMainWorld('novaAPI', {
    sendIntent: (intent) => electron_1.ipcRenderer.invoke('nova:intent', intent),
    onAgentState: (callback) => electron_1.ipcRenderer.on('nova:state', (_event, value) => callback(value)),
    onAgentProgress: (callback) => electron_1.ipcRenderer.on('nova:progress', (_event, value) => callback(value)),
    onAgentResponse: (callback) => electron_1.ipcRenderer.on('nova:response', (_event, value) => callback(value))
});
electron_1.contextBridge.exposeInMainWorld('ipc', {
    send: (channel, data) => electron_1.ipcRenderer.send(channel, data),
    invoke: (channel, ...args) => electron_1.ipcRenderer.invoke(channel, ...args),
    on: (channel, func) => {
        const subscription = (_event, ...args) => func(args[0]);
        electron_1.ipcRenderer.on(channel, subscription);
        return () => electron_1.ipcRenderer.removeListener(channel, subscription);
    }
});
