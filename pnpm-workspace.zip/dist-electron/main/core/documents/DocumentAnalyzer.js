"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentAnalyzer = void 0;
const DocumentParser_1 = require("../../services/documents/DocumentParser");
const DocumentChunker_1 = require("./DocumentChunker");
const DocumentSchemaValidator_1 = require("./DocumentSchemaValidator");
const logger_1 = require("../../services/logger");
class DocumentAnalyzer {
    constructor(aiProvider) {
        this.aiProvider = aiProvider;
    }
    async analyzeFile(filePath) {
        logger_1.logger.info(`[DocumentAnalyzer] Starting analysis pipeline for ${filePath}`);
        // 1. Extract Raw Text (never logged to prevent leaking sensitive info)
        const rawText = await DocumentParser_1.DocumentParser.parse(filePath);
        if (!rawText || rawText.trim().length === 0) {
            throw new Error(`Failed to extract meaningful text from ${filePath}`);
        }
        // 2. Chunking (For this MVP we will just analyze the first major chunk to save LLM context,
        // but in production we could map-reduce over all chunks).
        const chunks = DocumentChunker_1.DocumentChunker.chunkText(rawText);
        const primaryChunk = chunks[0] || '';
        // 3. AI Structured Extraction
        const prompt = `You are a highly capable document intelligence agent. 
    Analyze the following extracted document text and return a comprehensive structured analysis. 
    
    TEXT:
    ${primaryChunk.slice(0, 10000)}...`; // Failsafe slice to prevent overflowing context
        const analysis = await this.aiProvider.generateStructured(prompt, DocumentSchemaValidator_1.DocumentAnalysisSchema);
        logger_1.logger.info(`[DocumentAnalyzer] Successfully generated structured analysis for ${filePath}`);
        return analysis;
    }
}
exports.DocumentAnalyzer = DocumentAnalyzer;
