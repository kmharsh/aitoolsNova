"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BrowserExtractTool = void 0;
const zod_1 = require("zod");
const BaseTool_1 = require("../BaseTool");
const BrowserAgent_1 = require("../../browser/BrowserAgent");
const DownloadManager_1 = require("../../security/DownloadManager");
const browserAgent = new BrowserAgent_1.BrowserAgent(DownloadManager_1.downloadManager);
const InputSchema = zod_1.z.object({});
const OutputSchema = zod_1.z.object({
    text: zod_1.z.string(),
    links: zod_1.z.array(zod_1.z.object({ text: zod_1.z.string(), href: zod_1.z.string() }))
});
class BrowserExtractTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'browser.extract';
        this.description = 'Extracts readable text and links from the current browser page, stripping out clutter.';
        this.inputSchema = InputSchema;
        this.outputSchema = OutputSchema;
        this.riskLevel = 'LOW';
        this.requiresPermission = false;
        this.timeoutMs = 15000;
    }
    async execute(_input, context) {
        context.emitActivity(`Extracting content from page...`);
        const page = await browserAgent.getPage();
        // Evaluate in the browser context to strip clutter and return clean data
        const data = await page.evaluate(() => {
            // Remove scripts, styles, noscript, etc.
            document.querySelectorAll('script, style, noscript, svg, nav, footer, iframe').forEach(el => el.remove());
            const text = document.body.innerText.replace(/\n+/g, '\n').trim();
            const links = Array.from(document.querySelectorAll('a'))
                .filter(a => a.href && a.innerText.trim())
                .map(a => ({ text: a.innerText.trim(), href: a.href }))
                .slice(0, 50); // limit to top 50 links to avoid huge payloads
            return { text, links };
        });
        return data;
    }
}
exports.BrowserExtractTool = BrowserExtractTool;
