"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolRunner = void 0;
const ToolRegistry_1 = require("./ToolRegistry");
class ToolRunner {
    async execute(toolName, rawInput, context) {
        const tool = ToolRegistry_1.toolRegistry.get(toolName);
        if (!tool) {
            throw new Error(`Tool not found in registry: ${toolName}`);
        }
        // 1. Zod Input Validation
        // This strictly ensures the LLM didn't hallucinate invalid arguments
        const validatedInput = await tool.inputSchema.parseAsync(rawInput);
        // 2. Timeout and Execution
        return Promise.race([
            tool.execute(validatedInput, context),
            new Promise((_, reject) => {
                setTimeout(() => {
                    reject(new Error(`Tool ${toolName} timed out after ${tool.timeoutMs}ms`));
                }, tool.timeoutMs);
            })
        ]);
    }
}
exports.ToolRunner = ToolRunner;
