"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecurityEnforcer = void 0;
const SecurityAuditLog_1 = require("./SecurityAuditLog");
const logger_1 = require("../../services/logger");
class SecurityEnforcer {
    /**
     * Universal wrapper that strictly enforces constraints before executing ANY tool.
     */
    static async executeToolSecurely(agentName, tool, rawInput, context) {
        // 1. Zod Input Validation (Never trust the LLM)
        let safeInput;
        try {
            safeInput = tool.inputSchema.parse(rawInput);
        }
        catch (err) {
            logger_1.logger.error(`[SecurityEnforcer] Tool ${tool.name} failed schema validation: ${err.message}`);
            await SecurityAuditLog_1.SecurityAuditLog.logAction(agentName, tool.name, tool.riskLevel, rawInput, false);
            throw new Error(`Invalid arguments provided to tool ${tool.name}: ${err.message}`);
        }
        // 2. Permission / Risk Check
        if (tool.requiresPermission) {
            // In production, we'd trigger IPC to UI here and await a boolean.
            // For architecture demonstration, we assume context holds permission state or triggers it.
            logger_1.logger.warn(`[SecurityEnforcer] HIGH RISK ACTION DETECTED: ${tool.name}. Awaiting user confirmation.`);
            // if (!userConfirmed) throw new Error("User denied permission.");
        }
        // 3. Execution with Timeout
        let result;
        try {
            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error(`Tool execution timed out after ${tool.timeoutMs}ms`)), tool.timeoutMs);
            });
            const executionPromise = tool.execute(safeInput, context);
            result = await Promise.race([executionPromise, timeoutPromise]);
            // Log Success
            await SecurityAuditLog_1.SecurityAuditLog.logAction(agentName, tool.name, tool.riskLevel, safeInput, true);
            return result;
        }
        catch (err) {
            // Log Failure
            await SecurityAuditLog_1.SecurityAuditLog.logAction(agentName, tool.name, tool.riskLevel, safeInput, false);
            throw err;
        }
    }
}
exports.SecurityEnforcer = SecurityEnforcer;
