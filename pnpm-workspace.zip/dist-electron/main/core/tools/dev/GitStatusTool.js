"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitStatusTool = void 0;
const zod_1 = require("zod");
const BaseTool_1 = require("../BaseTool");
const child_process_1 = require("child_process");
const util_1 = require("util");
const execFileAsync = (0, util_1.promisify)(child_process_1.execFile);
const InputSchema = zod_1.z.object({
    repositoryPath: zod_1.z.string().describe('The path to the local git repository')
});
const OutputSchema = zod_1.z.object({
    statusOutput: zod_1.z.string()
});
class GitStatusTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'git.status';
        this.description = 'Returns the git status of a repository securely using execFile.';
        this.inputSchema = InputSchema;
        this.outputSchema = OutputSchema;
        this.riskLevel = 'LOW';
        this.requiresPermission = false;
        this.timeoutMs = 10000;
    }
    async execute(input, context) {
        context.emitActivity(`Checking git status for: ${input.repositoryPath}`);
        // Using execFile securely avoids shell injection because args are passed directly to the binary, not parsed by a shell.
        try {
            const { stdout } = await execFileAsync('git', ['status'], { cwd: input.repositoryPath });
            return { statusOutput: stdout };
        }
        catch (err) {
            throw new Error(`Git status failed: ${err.message || err.stderr}`);
        }
    }
}
exports.GitStatusTool = GitStatusTool;
