"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ComparisonSchema = void 0;
const zod_1 = require("zod");
exports.ComparisonSchema = zod_1.z.object({
    similarityScore: zod_1.z.number().describe('0 to 100 representing how similar the documents are'),
    summaryOfDifferences: zod_1.z.string().describe('A 2-sentence summary of the main changes'),
    metricChanges: zod_1.z.array(zod_1.z.object({
        metricName: zod_1.z.string(),
        oldValue: zod_1.z.string(),
        newValue: zod_1.z.string(),
        trend: zod_1.z.enum(['INCREASE', 'DECREASE', 'UNCHANGED', 'NEW'])
    })).optional().describe('Changes in critical numbers or KPIs'),
    newRisks: zod_1.z.array(zod_1.z.string()).optional().describe('Risks present in Doc 2 that were not in Doc 1'),
    resolvedRisks: zod_1.z.array(zod_1.z.string()).optional().describe('Risks present in Doc 1 that are missing in Doc 2'),
    timelineShifts: zod_1.z.array(zod_1.z.string()).optional().describe('Changes in dates, deadlines, or timelines'),
    strategicShifts: zod_1.z.array(zod_1.z.string()).optional().describe('Changes in overall strategy or recommendations'),
    matchedPoints: zod_1.z.array(zod_1.z.string()).optional().describe('Exact data points or paragraphs that are identical or match perfectly in both documents.'),
    unmatchedPoints: zod_1.z.array(zod_1.z.string()).optional().describe('Data points or claims that contradict each other or do not match at all between documents.')
});
