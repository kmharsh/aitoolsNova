"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.downloadManager = exports.DownloadManager = void 0;
const PathValidator_1 = require("./PathValidator");
const logger_1 = require("../../services/logger");
const path = __importStar(require("path"));
const fs_1 = require("fs");
const os = __importStar(require("os"));
class DownloadManager {
    constructor(downloadDir) {
        this.downloadDir = downloadDir;
        this.blockedExtensions = new Set(['.exe', '.bat', '.msi', '.ps1', '.cmd', '.scr', '.vbs']);
        this.maxSizeBytes = 100 * 1024 * 1024; // 100MB limit for AI downloads
    }
    async handlePlaywrightDownload(download) {
        logger_1.logger.info(`[DownloadManager] Intercepting download: ${download.url()}`);
        const suggestedFilename = download.suggestedFilename();
        const ext = path.extname(suggestedFilename).toLowerCase();
        // 1. Security Check: Block executables
        if (this.blockedExtensions.has(ext)) {
            logger_1.logger.error(`[DownloadManager] Blocked executable download: ${suggestedFilename}`);
            await download.cancel();
            throw new Error(`Security Exception: Downloading executable files (${ext}) is strictly prohibited.`);
        }
        // 2. Resolve destination safely using PathValidator
        const targetDest = path.join(this.downloadDir, suggestedFilename);
        const safeDest = PathValidator_1.pathValidator.validate(targetDest);
        // 3. Save the file temporarily to check size
        // Playwright downloads to a temp path, then we save it
        await download.saveAs(safeDest);
        // 4. Validate Size
        const stats = await fs_1.promises.stat(safeDest);
        if (stats.size > this.maxSizeBytes) {
            await fs_1.promises.unlink(safeDest); // delete immediately
            throw new Error(`Security Exception: Download exceeded maximum size of ${this.maxSizeBytes} bytes.`);
        }
        logger_1.logger.info(`[DownloadManager] Download safely saved to: ${safeDest}`);
    }
}
exports.DownloadManager = DownloadManager;
// We'll export a default instance for the global BrowserAgent
exports.downloadManager = new DownloadManager(path.join(os.homedir(), 'Downloads'));
