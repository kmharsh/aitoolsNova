"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FolderCreateTool = void 0;
const zod_1 = require("zod");
const BaseTool_1 = require("../BaseTool");
const fs_1 = require("fs");
const PathValidator_1 = require("../../security/PathValidator");
const InputSchema = zod_1.z.object({
    folderPath: zod_1.z.string().describe('The absolute or relative path to create the folder')
});
const OutputSchema = zod_1.z.object({
    success: zod_1.z.boolean(),
    path: zod_1.z.string()
});
class FolderCreateTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'filesystem.createFolder';
        this.description = 'Creates a new directory structure securely.';
        this.inputSchema = InputSchema;
        this.outputSchema = OutputSchema;
        this.riskLevel = 'MEDIUM'; // Modifying filesystem is medium risk
        this.requiresPermission = true; // Let's explicitly require permission to create folders
        this.timeoutMs = 5000;
    }
    async execute(input, context) {
        context.emitActivity(`Creating folder: ${input.folderPath}`);
        const resolvedPath = PathValidator_1.pathValidator.validate(input.folderPath);
        await fs_1.promises.mkdir(resolvedPath, { recursive: true });
        return {
            success: true,
            path: resolvedPath
        };
    }
}
exports.FolderCreateTool = FolderCreateTool;
