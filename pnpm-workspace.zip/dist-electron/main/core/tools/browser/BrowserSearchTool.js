"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BrowserSearchTool = void 0;
const zod_1 = require("zod");
const BaseTool_1 = require("../BaseTool");
const BrowserAgent_1 = require("../../browser/BrowserAgent");
const DownloadManager_1 = require("../../security/DownloadManager");
const browserAgent = new BrowserAgent_1.BrowserAgent(DownloadManager_1.downloadManager);
const InputSchema = zod_1.z.object({
    query: zod_1.z.string().describe('The search query')
});
const OutputSchema = zod_1.z.object({
    results: zod_1.z.array(zod_1.z.object({ title: zod_1.z.string(), href: zod_1.z.string(), snippet: zod_1.z.string() }))
});
class BrowserSearchTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'browser.search';
        this.description = 'Searches the web securely using DuckDuckGo.';
        this.inputSchema = InputSchema;
        this.outputSchema = OutputSchema;
        this.riskLevel = 'LOW';
        this.requiresPermission = false;
        this.timeoutMs = 20000;
    }
    async execute(input, context) {
        context.emitActivity(`Searching web for: ${input.query}`);
        const page = await browserAgent.getPage();
        const searchUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(input.query)}`;
        await page.goto(searchUrl, { waitUntil: 'domcontentloaded' });
        const results = await page.evaluate(() => {
            const resultNodes = document.querySelectorAll('.result');
            return Array.from(resultNodes).map(node => {
                const titleEl = node.querySelector('.result__title a');
                const snippetEl = node.querySelector('.result__snippet');
                return {
                    title: titleEl ? titleEl.innerText : '',
                    href: titleEl ? titleEl.href : '',
                    snippet: snippetEl ? snippetEl.innerText : ''
                };
            }).filter(r => r.title && r.href);
        });
        return { results };
    }
}
exports.BrowserSearchTool = BrowserSearchTool;
