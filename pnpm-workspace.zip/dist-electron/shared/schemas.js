"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskSchema = exports.StepSchema = void 0;
const zod_1 = require("zod");
exports.StepSchema = zod_1.z.object({
    id: zod_1.z.string(),
    description: zod_1.z.string(),
    tool: zod_1.z.string(),
    args: zod_1.z.record(zod_1.z.any()),
    status: zod_1.z.enum(['PENDING', 'RUNNING', 'COMPLETED', 'FAILED']).default('PENDING')
});
exports.TaskSchema = zod_1.z.object({
    id: zod_1.z.string(),
    intent: zod_1.z.string(),
    goal: zod_1.z.string(),
    steps: zod_1.z.array(exports.StepSchema),
    tools: zod_1.z.array(zod_1.z.string()),
    riskLevel: zod_1.z.enum(['LOW', 'MEDIUM', 'HIGH']),
    requiresConfirmation: zod_1.z.boolean(),
    status: zod_1.z.enum(['PLANNING', 'WAITING_FOR_PERMISSION', 'EXECUTING', 'COMPLETED', 'ERROR']).default('PLANNING')
});
