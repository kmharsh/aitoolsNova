"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExecutionEngine = void 0;
const logger_1 = require("../../services/logger");
class ExecutionEngine {
    constructor(taskManager) {
        this.taskManager = taskManager;
    }
    async execute(task, abortSignal) {
        logger_1.logger.info(`[ExecutionEngine] Starting execution for task: ${task.id}`);
        if (task.requiresConfirmation && task.riskLevel === 'HIGH') {
            this.taskManager.updateTaskStatus(task.id, 'WAITING_FOR_PERMISSION');
            logger_1.logger.info(`[ExecutionEngine] Task paused. Waiting for user permission.`);
            // In a real scenario, we wait for an IPC callback here
            // For this implementation, we will simulate a timeout or auto-allow based on mock logic
            await new Promise(resolve => setTimeout(resolve, 3000));
        }
        this.taskManager.updateTaskStatus(task.id, 'EXECUTING');
        for (const step of task.steps) {
            if (abortSignal?.aborted) {
                logger_1.logger.warn(`[ExecutionEngine] Task ${task.id} aborted.`);
                this.taskManager.updateTaskStatus(task.id, 'ERROR');
                return;
            }
            await this.executeStep(task.id, step);
        }
        this.taskManager.updateTaskStatus(task.id, 'COMPLETED');
        logger_1.logger.info(`[ExecutionEngine] Task ${task.id} completed successfully.`);
    }
    async executeStep(taskId, step) {
        this.taskManager.updateStepStatus(taskId, step.id, 'RUNNING');
        logger_1.logger.info(`[ExecutionEngine] Executing step: ${step.id} - ${step.description}`);
        try {
            // Simulate tool execution with timeout
            await this.runWithTimeout(async () => {
                // Mock execution delay
                await new Promise(resolve => setTimeout(resolve, 1500));
                // Throw random error for retry demonstration
                // if (Math.random() < 0.1) throw new Error("Network timeout");
            }, 5000);
            this.taskManager.updateStepStatus(taskId, step.id, 'COMPLETED');
        }
        catch (err) {
            logger_1.logger.error(`[ExecutionEngine] Step ${step.id} failed`, err);
            this.taskManager.updateStepStatus(taskId, step.id, 'FAILED');
            throw err; // Stop execution graph
        }
    }
    runWithTimeout(fn, timeoutMs) {
        return Promise.race([
            fn(),
            new Promise((_, reject) => setTimeout(() => reject(new Error(`Timeout after ${timeoutMs}ms`)), timeoutMs))
        ]);
    }
}
exports.ExecutionEngine = ExecutionEngine;
