"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dbManager = exports.DBManager = void 0;
const logger_1 = require("./logger");
class DBManager {
    connect(dbPath) {
        logger_1.logger.info(`[Mock] Connected to database at ${dbPath}`);
        this.initSchema();
    }
    initSchema() {
        logger_1.logger.info('[Mock] Database schema initialized.');
    }
    getDb() {
        return {
            prepare: () => ({ run: () => { } })
        };
    }
}
exports.DBManager = DBManager;
exports.dbManager = new DBManager();
