"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MockTTSProvider = exports.MockSTTProvider = void 0;
const logger_1 = require("../logger");
class MockSTTProvider {
    async transcribe(audioData) {
        logger_1.logger.info(`[MockSTT] Processing ${audioData.byteLength} bytes of audio...`);
        // Simulate processing time
        await new Promise(resolve => setTimeout(resolve, 1500));
        return "This is a simulated transcription of your voice command.";
    }
}
exports.MockSTTProvider = MockSTTProvider;
class MockTTSProvider {
    async synthesize(text) {
        logger_1.logger.info(`[MockTTS] Synthesizing speech for: ${text}`);
        // Simulate synthesis time
        await new Promise(resolve => setTimeout(resolve, 1000));
        // Return empty buffer as mock audio
        return new ArrayBuffer(0);
    }
}
exports.MockTTSProvider = MockTTSProvider;
