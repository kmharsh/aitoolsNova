"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FSDStructureSchema = exports.DocumentAnalysisSchema = void 0;
const zod_1 = require("zod");
const flexStrArr = (desc) => zod_1.z.preprocess((val) => {
    if (Array.isArray(val)) {
        return val.map(item => typeof item === 'string' ? item : JSON.stringify(item));
    }
    else if (typeof val === 'object' && val !== null) {
        return [JSON.stringify(val)];
    }
    else if (val !== undefined && val !== null) {
        return [String(val)];
    }
    return [];
}, zod_1.z.array(zod_1.z.string())).describe(desc);
const flexStrArrOpt = (desc) => zod_1.z.preprocess((val) => {
    if (val === undefined || val === null)
        return undefined;
    if (Array.isArray(val)) {
        return val.map(item => typeof item === 'string' ? item : JSON.stringify(item));
    }
    else if (typeof val === 'object' && val !== null) {
        return [JSON.stringify(val)];
    }
    else if (val !== undefined && val !== null) {
        return [String(val)];
    }
    return [];
}, zod_1.z.array(zod_1.z.string())).optional().describe(desc);
exports.DocumentAnalysisSchema = zod_1.z.object({
    documentType: zod_1.z.string().describe('Inferred type of document based on content (e.g. Invoice, Report, Resume)'),
    title: zod_1.z.string().describe('Extracted or inferred title'),
    summary: zod_1.z.string().describe('A concise 2-3 sentence summary of the document'),
    keyPoints: flexStrArr('Top 3 to 5 critical takeaways'),
    entities: flexStrArrOpt('Important people, companies, or organizations mentioned'),
    importantNumbers: flexStrArrOpt('Key financial figures, IDs, or metrics'),
    dates: flexStrArrOpt('Important dates mentioned'),
    risks: flexStrArrOpt('Any potential risks or warnings identified'),
    recommendations: flexStrArrOpt('Any recommended next steps or action items'),
    relationships: flexStrArrOpt('Relationships between key entities'),
    sections: flexStrArrOpt('List of major headers or sections found'),
    fsdBlueprint: zod_1.z.lazy(() => exports.FSDStructureSchema).optional().describe('Generated project structure if this is an FSD'),
    securityClearance: zod_1.z.enum(['PUBLIC', 'INTERNAL', 'CONFIDENTIAL', 'HIGH RISK']).optional().describe('Inferred security/risk level of the document'),
    actionItems: flexStrArrOpt('List of next steps or tasks extracted from the document')
});
exports.FSDStructureSchema = zod_1.z.object({
    projectName: zod_1.z.string().describe('The overall name of the project'),
    frontendComponents: flexStrArr('List of React/UI components to build'),
    backendEndpoints: flexStrArr('List of API routes/endpoints needed'),
    databaseModels: flexStrArr('List of database schemas/models'),
    businessLogic: flexStrArr('Key business rules or logical workflows'),
    architecture: zod_1.z.string().optional().describe('High level system architecture (e.g., Microservices, Monolithic)'),
    systemDesign: flexStrArrOpt('Key system design patterns or decisions'),
    dependencies: flexStrArrOpt('Required external libraries or tools')
});
