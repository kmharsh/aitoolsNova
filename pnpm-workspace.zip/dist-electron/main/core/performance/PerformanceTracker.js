"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PerformanceTracker = void 0;
const logger_1 = require("../../services/logger");
class PerformanceTracker {
    constructor() {
        this.metrics = {};
        this.startTime = Date.now();
    }
    recordAIPlanning(durationMs) {
        this.metrics.aiPlanningMs = durationMs;
    }
    recordToolExecution(durationMs) {
        this.metrics.toolExecutionMs = (this.metrics.toolExecutionMs || 0) + durationMs;
    }
    recordDocumentProcessing(durationMs) {
        this.metrics.documentProcessingMs = (this.metrics.documentProcessingMs || 0) + durationMs;
    }
    getMetrics() {
        const totalMs = Date.now() - this.startTime;
        return {
            aiPlanningMs: this.metrics.aiPlanningMs || 0,
            toolExecutionMs: this.metrics.toolExecutionMs || 0,
            documentProcessingMs: this.metrics.documentProcessingMs || 0,
            totalMs
        };
    }
    logFinal() {
        const m = this.getMetrics();
        logger_1.logger.info(`[Performance] AI: ${m.aiPlanningMs}ms | Tools: ${m.toolExecutionMs}ms | Docs: ${m.documentProcessingMs}ms | TOTAL: ${m.totalMs}ms`);
    }
}
exports.PerformanceTracker = PerformanceTracker;
