"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentChunker = void 0;
class DocumentChunker {
    /**
     * Splits a massive string into smaller chunks by paragraph/newlines to avoid breaking
     * semantic meaning, aiming for approx 'maxChunkLength' characters.
     */
    static chunkText(text, maxChunkLength = 4000) {
        if (!text)
            return [];
        const paragraphs = text.split(/\n\s*\n/);
        const chunks = [];
        let currentChunk = '';
        for (const paragraph of paragraphs) {
            if (currentChunk.length + paragraph.length > maxChunkLength && currentChunk.length > 0) {
                chunks.push(currentChunk.trim());
                currentChunk = '';
            }
            currentChunk += paragraph + '\n\n';
        }
        if (currentChunk.trim().length > 0) {
            chunks.push(currentChunk.trim());
        }
        return chunks;
    }
}
exports.DocumentChunker = DocumentChunker;
