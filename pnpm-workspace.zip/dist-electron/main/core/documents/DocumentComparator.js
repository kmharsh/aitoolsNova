"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentComparator = void 0;
const ComparisonSchemaValidator_1 = require("./ComparisonSchemaValidator");
const logger_1 = require("../../services/logger");
class DocumentComparator {
    constructor(aiProvider) {
        this.aiProvider = aiProvider;
    }
    async compareDocuments(doc1, doc2) {
        logger_1.logger.info(`[DocumentComparator] Diffing "${doc1.title}" against "${doc2.title}"`);
        const prompt = `You are an expert document analyst. Compare these two document structures.
    Document 1 (Older/Base): ${JSON.stringify(doc1)}
    Document 2 (Newer/Target): ${JSON.stringify(doc2)}
    
    Calculate the differences in metrics, risks, and strategies and output a structured comparison.`;
        const comparison = await this.aiProvider.generateStructured(prompt, ComparisonSchemaValidator_1.ComparisonSchema);
        logger_1.logger.info(`[DocumentComparator] Comparison complete. Score: ${comparison.similarityScore}`);
        return comparison;
    }
}
exports.DocumentComparator = DocumentComparator;
