"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.pathValidator = exports.PathValidator = void 0;
const path = __importStar(require("path"));
class PathValidator {
    constructor(allowedRoots = []) {
        // Default to resolving allowed roots to absolute paths
        this.allowedRoots = allowedRoots.map(root => path.resolve(root));
        // Hardcoded strict blocklist for secrets and system files
        this.blacklistedNames = new Set([
            '.env',
            'credentials',
            'id_rsa',
            'id_ed25519',
            'secrets.json',
            'config.json',
            '.git',
            '.ssh'
        ]);
    }
    /**
     * Resolves the path and ensures it does not attempt directory traversal
     * outside of the allowed roots, and doesn't touch blacklisted files.
     */
    validate(targetPath) {
        const resolvedPath = path.resolve(targetPath);
        // 1. Check for basic traversal attacks manually (though path.resolve handles most)
        if (targetPath.includes('..') && !this.isWithinAllowedRoots(resolvedPath)) {
            throw new Error(`Security Exception: Directory traversal attempt detected -> ${targetPath}`);
        }
        // 2. Check Blacklist
        const basename = path.basename(resolvedPath).toLowerCase();
        if (this.blacklistedNames.has(basename)) {
            throw new Error(`Security Exception: Access to protected file blocked -> ${basename}`);
        }
        // 3. Windows System Protection
        if (resolvedPath.toLowerCase().startsWith('c:\\windows') ||
            resolvedPath.toLowerCase().startsWith('c:\\program files')) {
            throw new Error(`Security Exception: Access to Windows system directories is blocked.`);
        }
        // 4. Check Allowed Roots
        if (!this.isWithinAllowedRoots(resolvedPath)) {
            throw new Error(`Security Exception: Path is outside of allowed directories -> ${resolvedPath}`);
        }
        return resolvedPath;
    }
    isWithinAllowedRoots(resolvedPath) {
        if (this.allowedRoots.length === 0)
            return true; // If empty, assume full C:\Users\ minus system dirs is allowed.
        return this.allowedRoots.some(root => {
            const relative = path.relative(root, resolvedPath);
            // If the relative path does not start with '..', it is inside the root
            return !relative.startsWith('..') && !path.isAbsolute(relative);
        });
    }
}
exports.PathValidator = PathValidator;
// Global instance (configured for user profile by default)
exports.pathValidator = new PathValidator([
    process.env.USERPROFILE || 'C:\\Users'
]);
