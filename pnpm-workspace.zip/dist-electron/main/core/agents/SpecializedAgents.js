"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommunicationAgent = exports.FileAgent = exports.DeveloperAgent = exports.DocumentAgent = exports.BrowserAgent = void 0;
const BaseAgent_1 = require("./BaseAgent");
class BrowserAgent extends BaseAgent_1.BaseAgent {
    constructor() {
        super(...arguments);
        this.name = 'BrowserAgent';
        this.description = 'Handles web navigation, DOM extraction, and downloads via Playwright.';
    }
}
exports.BrowserAgent = BrowserAgent;
class DocumentAgent extends BaseAgent_1.BaseAgent {
    constructor() {
        super(...arguments);
        this.name = 'DocumentAgent';
        this.description = 'Handles parsing, chunking, and comparing complex documents (PDFs, CSVs).';
    }
}
exports.DocumentAgent = DocumentAgent;
class DeveloperAgent extends BaseAgent_1.BaseAgent {
    constructor() {
        super(...arguments);
        this.name = 'DeveloperAgent';
        this.description = 'Handles repository inspection, git commits, and code modification.';
    }
}
exports.DeveloperAgent = DeveloperAgent;
class FileAgent extends BaseAgent_1.BaseAgent {
    constructor() {
        super(...arguments);
        this.name = 'FileAgent';
        this.description = 'Handles secure file system operations (copy, move, delete).';
    }
}
exports.FileAgent = FileAgent;
class CommunicationAgent extends BaseAgent_1.BaseAgent {
    constructor() {
        super(...arguments);
        this.name = 'CommunicationAgent';
        this.description = 'Interfaces with the Voice TTS/STT and Memory databases.';
    }
}
exports.CommunicationAgent = CommunicationAgent;
