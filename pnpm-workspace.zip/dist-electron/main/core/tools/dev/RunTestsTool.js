"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RunTestsTool = void 0;
const BaseTool_1 = require("../BaseTool");
const zod_1 = require("zod");
const child_process_1 = require("child_process");
const util_1 = require("util");
const PathValidator_1 = require("../../security/PathValidator");
const execAsync = (0, util_1.promisify)(child_process_1.exec);
class RunTestsTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'developer.runTests';
        this.description = 'Executes the test suite in the target repository.';
        this.inputSchema = zod_1.z.object({
            repoPath: zod_1.z.string().describe('Absolute path to the repository root.'),
            command: zod_1.z.string().describe('Test command to run (e.g., "npm test").')
        });
        this.outputSchema = zod_1.z.any();
        this.riskLevel = 'LOW';
        this.requiresPermission = false;
        this.timeoutMs = 60000;
    }
    async execute(input, _context) {
        try {
            PathValidator_1.pathValidator.validate(input.repoPath);
        }
        catch (e) {
            throw new Error(`Access Denied.`);
        }
        try {
            if (!input.command.startsWith('npm ') && !input.command.startsWith('yarn ') && !input.command.startsWith('pnpm ')) {
                throw new Error('Only npm/yarn/pnpm commands are allowed for testing.');
            }
            const { stdout, stderr } = await execAsync(input.command, { cwd: input.repoPath });
            return { stdout, stderr };
        }
        catch (err) {
            return { failed: true, output: err.message || err.stdout || err.stderr };
        }
    }
}
exports.RunTestsTool = RunTestsTool;
