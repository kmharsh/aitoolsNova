"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskManager = void 0;
const logger_1 = require("../../services/logger");
class TaskManager {
    constructor() {
        this.activeTasks = new Map();
        this.mainWindow = null;
    }
    setWindow(window) {
        this.mainWindow = window;
    }
    register(task) {
        this.activeTasks.set(task.id, task);
        this.broadcastState('PLANNING');
    }
    updateTaskStatus(taskId, status) {
        const task = this.activeTasks.get(taskId);
        if (task) {
            task.status = status;
            this.broadcastState(status);
            this.broadcastProgress(task);
        }
    }
    updateStepStatus(taskId, stepId, status) {
        const task = this.activeTasks.get(taskId);
        if (task) {
            const step = task.steps.find((s) => s.id === stepId);
            if (step) {
                step.status = status;
                this.broadcastProgress(task);
            }
        }
    }
    broadcastState(state) {
        if (this.mainWindow) {
            this.mainWindow.webContents.send('nova:state', state);
            logger_1.logger.info(`[TaskManager] State changed -> ${state}`);
        }
    }
    broadcastProgress(task) {
        if (this.mainWindow) {
            this.mainWindow.webContents.send('nova:progress', task);
        }
    }
}
exports.TaskManager = TaskManager;
