"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MasterOrchestrator = void 0;
const SpecializedAgents_1 = require("../agents/SpecializedAgents");
const logger_1 = require("../../services/logger");
class MasterOrchestrator {
    constructor(_aiProvider) {
        this.agents = new Map();
        // Initialize the Sub-Agent cluster
        this.agents.set('BrowserAgent', new SpecializedAgents_1.BrowserAgent(_aiProvider));
        this.agents.set('DocumentAgent', new SpecializedAgents_1.DocumentAgent(_aiProvider));
        this.agents.set('DeveloperAgent', new SpecializedAgents_1.DeveloperAgent(_aiProvider));
        this.agents.set('FileAgent', new SpecializedAgents_1.FileAgent(_aiProvider));
        this.agents.set('CommunicationAgent', new SpecializedAgents_1.CommunicationAgent(_aiProvider));
    }
    /**
     * The Hub-and-Spoke router.
     * Breaks a high-level intent into sequential tasks and routes them to specialized agents.
     */
    async executeComplexIntent(intent) {
        logger_1.logger.info(`[MasterOrchestrator] Deconstructing intent: "${intent}"`);
        // In production, the LLM would generate this Execution Graph dynamically.
        // For demonstration of the Hub-and-Spoke architecture, we build a static execution graph.
        const tasks = [];
        if (intent.toLowerCase().includes('download') && intent.toLowerCase().includes('summarize')) {
            tasks.push({
                targetAgent: 'BrowserAgent',
                task: { id: 't1', description: 'Navigate to URL and download the annual report.' }
            });
            tasks.push({
                targetAgent: 'FileAgent',
                task: { id: 't2', description: 'Securely move the downloaded file to the active workspace.' }
            });
            tasks.push({
                targetAgent: 'DocumentAgent',
                task: { id: 't3', description: 'Parse the PDF, chunk it, and extract a structured summary.' }
            });
            tasks.push({
                targetAgent: 'CommunicationAgent',
                task: { id: 't4', description: 'Speak the summary aloud to the user via TTS.' }
            });
        }
        else {
            // Generic fallback route
            tasks.push({
                targetAgent: 'CommunicationAgent',
                task: { id: 't_gen', description: intent }
            });
        }
        const results = [];
        // Execute sequentially (Hub-and-Spoke model: Agent -> Orchestrator -> Agent)
        for (const step of tasks) {
            const agent = this.agents.get(step.targetAgent);
            if (!agent) {
                throw new Error(`[MasterOrchestrator] Fatal: Required agent ${step.targetAgent} not found in cluster.`);
            }
            logger_1.logger.info(`[MasterOrchestrator] Routing Task [${step.task.id}] to ${agent.name}`);
            // Execute the task via the specific sub-agent
            const result = await agent.executeTask(step.task, { emitActivity: (msg) => logger_1.logger.info(msg) });
            results.push(result);
            if (!result.success) {
                logger_1.logger.error(`[MasterOrchestrator] Execution halted. ${agent.name} failed task ${step.task.id}`);
                break; // Halt the execution graph if a dependency fails
            }
        }
        return results;
    }
}
exports.MasterOrchestrator = MasterOrchestrator;
