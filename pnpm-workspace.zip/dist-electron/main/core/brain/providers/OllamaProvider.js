"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.OllamaProvider = void 0;
const logger_1 = require("../../../services/logger");
const crypto = __importStar(require("crypto"));
class OllamaProvider {
    constructor(model = 'llama3') {
        this.baseUrl = 'http://localhost:11434/api';
        this.model = model;
    }
    hashPrompt(prompt) {
        return crypto.createHash('sha256').update(prompt).digest('hex');
    }
    async generateResponse(prompt, systemPrompt) {
        const hash = this.hashPrompt(prompt + (systemPrompt || ''));
        if (OllamaProvider.responseCache.has(hash)) {
            logger_1.logger.info(`[OllamaProvider] Cache hit! Returning instant response.`);
            return OllamaProvider.responseCache.get(hash);
        }
        logger_1.logger.info(`[OllamaProvider] Generating response with ${this.model}...`);
        try {
            const res = await fetch(`${this.baseUrl}/generate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: this.model,
                    system: systemPrompt || 'You are Nova, an advanced AI assistant. Your responses must be extremely short, concise, and helpful. Do not babble.',
                    prompt,
                    stream: false
                })
            });
            if (!res.ok)
                throw new Error(`Ollama HTTP Error: ${res.status}`);
            const data = await res.json();
            OllamaProvider.responseCache.set(hash, data.response);
            return data.response;
        }
        catch (err) {
            logger_1.logger.error('[OllamaProvider] Generation failed', err);
            throw err;
        }
    }
    async *streamResponse(prompt) {
        logger_1.logger.info(`[OllamaProvider] Streaming response with ${this.model}...`);
        const res = await fetch(`${this.baseUrl}/generate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: this.model,
                prompt,
                stream: true
            })
        });
        if (!res.ok || !res.body)
            throw new Error(`Ollama HTTP Error: ${res.status}`);
        const reader = res.body.getReader();
        const decoder = new TextDecoder('utf-8');
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            const chunk = decoder.decode(value, { stream: true });
            const lines = chunk.split('\n').filter(Boolean);
            for (const line of lines) {
                try {
                    const parsed = JSON.parse(line);
                    if (parsed.response)
                        yield parsed.response;
                }
                catch (e) {
                    // ignore parse errors for partial chunks
                }
            }
        }
    }
    async generateStructured(prompt, schema) {
        const hash = this.hashPrompt(prompt);
        if (OllamaProvider.structuredCache.has(hash)) {
            logger_1.logger.info(`[OllamaProvider] Cache hit! Returning instant structured data.`);
            return OllamaProvider.structuredCache.get(hash);
        }
        logger_1.logger.info(`[OllamaProvider] Generating structured output with ${this.model}...`);
        // Inject the JSON schema instruction into the prompt
        // Ollama supports `format: "json"` which guarantees a valid JSON object.
        const systemPrompt = `You are a strict data extraction AI. Output ONLY valid JSON that matches the following instruction. Do not include markdown code blocks (\`\`\`json) or any conversational text. Just the raw JSON object.`;
        const fullPrompt = `${systemPrompt}\n\n${prompt}`;
        try {
            const res = await fetch(`${this.baseUrl}/generate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: this.model,
                    prompt: fullPrompt,
                    stream: false,
                    format: 'json'
                })
            });
            if (!res.ok)
                throw new Error(`Ollama HTTP Error: ${res.status}`);
            const data = await res.json();
            let parsedJson = data.response;
            // In case Ollama returns a stringified JSON string instead of an object, parse it
            if (typeof parsedJson === 'string') {
                parsedJson = JSON.parse(parsedJson);
            }
            // Validate against the Zod schema
            const validData = schema.parse(parsedJson);
            OllamaProvider.structuredCache.set(hash, validData);
            return validData;
        }
        catch (err) {
            logger_1.logger.error('[OllamaProvider] Structured generation failed', err);
            throw err;
        }
    }
}
exports.OllamaProvider = OllamaProvider;
// Global cache across all provider instances
OllamaProvider.responseCache = new Map();
OllamaProvider.structuredCache = new Map();
