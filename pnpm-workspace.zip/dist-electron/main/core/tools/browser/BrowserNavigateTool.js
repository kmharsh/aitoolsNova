"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BrowserNavigateTool = void 0;
const zod_1 = require("zod");
const BaseTool_1 = require("../BaseTool");
const BrowserAgent_1 = require("../../browser/BrowserAgent");
const DownloadManager_1 = require("../../security/DownloadManager");
// Instantiate the global agent
const browserAgent = new BrowserAgent_1.BrowserAgent(DownloadManager_1.downloadManager);
const InputSchema = zod_1.z.object({
    url: zod_1.z.string().url().describe('The valid URL to navigate to')
});
const OutputSchema = zod_1.z.object({
    title: zod_1.z.string(),
    success: zod_1.z.boolean()
});
class BrowserNavigateTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'browser.navigate';
        this.description = 'Navigates the internal browser to a specific URL.';
        this.inputSchema = InputSchema;
        this.outputSchema = OutputSchema;
        this.riskLevel = 'LOW';
        this.requiresPermission = false;
        this.timeoutMs = 30000;
    }
    async execute(input, context) {
        context.emitActivity(`Navigating to ${input.url}`);
        const page = await browserAgent.getPage();
        const response = await page.goto(input.url, { waitUntil: 'domcontentloaded' });
        if (!response || !response.ok()) {
            throw new Error(`Navigation failed with status ${response?.status()}`);
        }
        const title = await page.title();
        return {
            title,
            success: true
        };
    }
}
exports.BrowserNavigateTool = BrowserNavigateTool;
