"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentParser = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const OCRProcessor_1 = require("./OCRProcessor");
// Use dynamic imports or requires for heavy libraries to keep startup fast
const pdf = require('pdf-parse');
const mammoth = require('mammoth');
const xlsx = require('xlsx');
class DocumentParser {
    static async parse(filePath) {
        const ext = path.extname(filePath).toLowerCase();
        switch (ext) {
            case '.txt':
            case '.md':
            case '.json':
                return await fs.promises.readFile(filePath, 'utf8');
            case '.pdf':
                const pdfBuffer = await fs.promises.readFile(filePath);
                const pdfData = await pdf(pdfBuffer);
                return pdfData.text;
            case '.docx':
                const docxResult = await mammoth.extractRawText({ path: filePath });
                return docxResult.value;
            case '.xlsx':
            case '.csv':
                // For CSV, we can stream. But for simplicity of returning a single string, we use xlsx for both if small enough.
                const workbook = xlsx.readFile(filePath);
                const sheetName = workbook.SheetNames[0];
                const sheet = workbook.Sheets[sheetName];
                return xlsx.utils.sheet_to_csv(sheet);
            case '.png':
            case '.jpg':
            case '.jpeg':
                return await OCRProcessor_1.OCRProcessor.extractText(filePath);
            default:
                throw new Error(`Unsupported document type: ${ext}`);
        }
    }
}
exports.DocumentParser = DocumentParser;
