"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("./core/error-handler");
const electron_1 = require("electron");
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
const logger_1 = require("./services/logger");
const db_1 = require("./services/db");
const env_1 = require("./core/env");
const pdf_parse_1 = __importDefault(require("pdf-parse"));
// Core dependencies
const MockProvider_1 = require("./core/brain/providers/MockProvider");
const OllamaProvider_1 = require("./core/brain/providers/OllamaProvider");
const TaskManager_1 = require("./core/brain/TaskManager");
const AgentOrchestrator_1 = require("./core/brain/AgentOrchestrator");
const VoiceManager_1 = require("./services/audio/VoiceManager");
const MockProviders_1 = require("./services/audio/MockProviders");
const MemoryManager_1 = require("./core/memory/MemoryManager");
const DocumentSchemaValidator_1 = require("./core/documents/DocumentSchemaValidator");
// Instantiate globally
const taskManager = new TaskManager_1.TaskManager();
const provider = new MockProvider_1.MockProvider();
const orchestrator = new AgentOrchestrator_1.AgentOrchestrator(provider, taskManager);
const stt = new MockProviders_1.MockSTTProvider();
const tts = new MockProviders_1.MockTTSProvider();
const voiceManager = new VoiceManager_1.VoiceManager(stt, tts, orchestrator);
const memoryManager = new MemoryManager_1.MemoryManager(electron_1.app.getPath('userData'));
// Initialize async memory store later inside app.whenReady
let mainWindow = null;
function createWindow() {
    mainWindow = new electron_1.BrowserWindow({
        width: 1200,
        height: 800,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            nodeIntegration: false,
            contextIsolation: true,
        }
    });
    const isDev = !electron_1.app.isPackaged;
    if (isDev) {
        mainWindow.loadURL('http://localhost:5173');
        // mainWindow.webContents.openDevTools(); // Disabled auto-opening Inspect panel
    }
    else {
        mainWindow.loadFile(path.join(__dirname, '../../dist/index.html'));
    }
    taskManager.setWindow(mainWindow);
}
const expressServer_1 = require("./expressServer");
electron_1.app.whenReady().then(async () => {
    logger_1.logger.info('NOVA Core starting up...');
    // Wait for database to load before UI starts asking for it!
    await memoryManager.init();
    // Start the REST API server for Chrome Browser support
    (0, expressServer_1.startExpressServer)(memoryManager);
    // Auto-grant microphone permissions for the renderer
    electron_1.session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
        if (permission === 'media') {
            logger_1.logger.info('Granted media (microphone) permission to renderer.');
            callback(true);
        }
        else {
            callback(false);
        }
    });
    electron_1.session.defaultSession.setPermissionCheckHandler((_webContents, permission) => {
        if (permission === 'media')
            return true;
        return false;
    });
    // Initialize Database
    try {
        db_1.dbManager.connect(env_1.env.DATABASE_PATH);
        // Voice Flow
        electron_1.ipcMain.on('nova:audio:chunk', async (event, audioBuffer) => {
            logger_1.logger.info('Received audio chunk from renderer');
            const win = electron_1.BrowserWindow.fromWebContents(event.sender);
            if (win) {
                // Run completely asynchronously to not block IPC
                voiceManager.processIncomingAudio(audioBuffer, win).catch(err => {
                    logger_1.logger.error(`VoiceManager unhandled error: ${err}`);
                });
            }
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to initialize database during startup', error instanceof Error ? error : new Error(String(error)));
        electron_1.app.quit();
        return;
    }
    let tray = null;
    // Create a blank tray icon or use a default one
    tray = new electron_1.Tray(electron_1.nativeImage.createEmpty());
    const contextMenu = electron_1.Menu.buildFromTemplate([
        {
            label: 'Open Nova Window',
            click: () => {
                if (electron_1.BrowserWindow.getAllWindows().length === 0) {
                    createWindow();
                }
                else if (mainWindow) {
                    mainWindow.show();
                }
            }
        },
        { label: 'Quit Nova Backend', click: () => { electron_1.app.quit(); } }
    ]);
    tray.setToolTip('Nova AI Backend Server');
    tray.setTitle('Nova');
    tray.setContextMenu(contextMenu);
    // We no longer automatically open the window on startup
    // createWindow();
    electron_1.app.on('activate', () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});
// Do not quit when windows are closed, so the background API keeps running
electron_1.app.on('window-all-closed', () => {
    // We want the backend to stay alive even if the desktop window is closed!
});
electron_1.ipcMain.handle('nova:intent', async (_event, intent) => {
    // Fire and forget so the UI doesn't block while the pipeline runs
    orchestrator.processIntent(intent);
    return { success: true, message: 'Intent dispatched to Orchestrator.' };
});
// Chat IPC
electron_1.ipcMain.handle('nova:chat', async (_event, text) => {
    try {
        // 1. Add user message to memory
        await memoryManager.addChatMessage('user', text);
        // 2. Build prompt context
        const longTermContext = memoryManager.getLongTermContext();
        const chatHistory = memoryManager.getChatHistory();
        const enrichedPrompt = `
Context about the user:
${longTermContext ? longTermContext : "None"}

Recent conversation history:
${chatHistory}

Now, answer the user's latest query:
USER: ${text}
`;
        const ollama = new OllamaProvider_1.OllamaProvider('llama3.2');
        const response = await ollama.generateResponse(enrichedPrompt);
        // 3. Save assistant response to memory
        await memoryManager.addChatMessage('assistant', response);
        return response;
    }
    catch (err) {
        logger_1.logger.error('Failed to generate chat response', err);
        return "I'm sorry, I couldn't connect to my AI brain. Is Ollama running?";
    }
});
// Memory IPC
electron_1.ipcMain.handle('nova:memory:getAll', async () => {
    return memoryManager.getAllMemories();
});
electron_1.ipcMain.handle('nova:memory:save', async (_event, data) => {
    await memoryManager.storeMemory(data.type, data.key, data.value);
    return { success: true };
});
electron_1.ipcMain.handle('nova:memory:clearAll', async () => {
    await memoryManager.clearAll();
    return { success: true };
});
electron_1.ipcMain.handle('nova:memory:delete', async (_event, type, key) => {
    await memoryManager.deleteMemory(type, key);
    return { success: true };
});
electron_1.ipcMain.handle('nova:memory:toggle', async (_event, enabled) => {
    memoryManager.setMemoryEnabled(enabled);
    return { success: true };
});
// Handle opening OS settings directly from UI
electron_1.ipcMain.on('nova:open-settings', (_event, uri) => {
    electron_1.shell.openExternal(uri);
});
// Dynamic Document Pipeline
electron_1.ipcMain.handle('nova:document:upload', async (_event, filePath) => {
    try {
        logger_1.logger.info(`[DocumentPipeline] Reading file: ${filePath}`);
        const dataBuffer = fs.readFileSync(filePath);
        let extractedText = '';
        if (filePath.toLowerCase().endsWith('.pdf')) {
            const pdfData = await (0, pdf_parse_1.default)(dataBuffer);
            extractedText = pdfData.text;
        }
        else {
            extractedText = dataBuffer.toString('utf8');
        }
        let result;
        try {
            const ollama = new OllamaProvider_1.OllamaProvider('llama3.2');
            const prompt = `Analyze the following document text and extract the required information into a JSON object:\n\nTEXT:\n${extractedText}`;
            logger_1.logger.info(`[DocumentPipeline] Sending text to AI for analysis...`);
            result = await ollama.generateStructured(prompt, DocumentSchemaValidator_1.DocumentAnalysisSchema);
        }
        catch (llmError) {
            logger_1.logger.warn(`[DocumentPipeline] AI failed to extract JSON (common with tiny models). Using fallback extraction.`);
            // Fallback so the frontend UI can still render and the user isn't blocked
            result = {
                documentType: "General Document",
                title: path.basename(filePath),
                summary: `This is a fallback summary because the 'tinyllama' model failed to output a valid JSON structure. The document contains ${extractedText.length} characters of text.`,
                keyPoints: ["Document successfully loaded into memory", "AI failed strict JSON extraction", "Raw text is available for search"],
                entities: ["User", "System"],
                importantNumbers: [String(extractedText.length)],
                dates: [new Date().toLocaleDateString()],
                risks: ["Model parsing failure"],
                recommendations: ["Upgrade to a larger model like llama3 for accurate data extraction"],
                relationships: ["Nova -> Local System"],
                sections: ["Introduction", "Raw Data"]
            };
        }
        logger_1.logger.info(`[DocumentPipeline] Analysis complete!`);
        return result;
    }
    catch (error) {
        logger_1.logger.error(`[DocumentPipeline] Failed to process document`, error);
        throw error;
    }
});
const ComparisonSchemaValidator_1 = require("./core/documents/ComparisonSchemaValidator");
electron_1.ipcMain.handle('nova:document:compare', async (_event, doc1, doc2) => {
    try {
        logger_1.logger.info(`[DocumentPipeline] Comparing documents: ${doc1.title} vs ${doc2.title}`);
        let result;
        try {
            const ollama = new OllamaProvider_1.OllamaProvider('llama3.2');
            const prompt = `Compare these two document summaries and output a strict JSON array representing the differences:\n\nDOC 1: ${JSON.stringify(doc1)}\n\nDOC 2: ${JSON.stringify(doc2)}`;
            logger_1.logger.info(`[DocumentPipeline] Sending comparison to AI...`);
            result = await ollama.generateStructured(prompt, ComparisonSchemaValidator_1.ComparisonSchema);
        }
        catch (llmError) {
            logger_1.logger.warn(`[DocumentPipeline] AI failed to extract comparison JSON. Using fallback extraction.`);
            // Fallback so the frontend UI can still render and the user isn't blocked
            result = {
                similarityScore: 42,
                summaryOfDifferences: `This is a fallback comparison. Model 'tinyllama' failed strict JSON extraction. Doc 1: ${doc1.title}, Doc 2: ${doc2.title}`,
                metricChanges: [
                    { metricName: 'Length', oldValue: 'Varies', newValue: 'Varies', trend: 'UNCHANGED' },
                    { metricName: 'Complexity', oldValue: 'High', newValue: 'Low', trend: 'DECREASE' }
                ],
                newRisks: ['Fallback parsing used - data may be inaccurate'],
                resolvedRisks: [],
                timelineShifts: ['Immediate analysis fallback triggered'],
                strategicShifts: ['Upgrade model to llama3 for accurate comparison'],
                matchedPoints: [
                    'Both documents belong to the same project context',
                    'Formatting structure is similar'
                ],
                unmatchedPoints: [
                    'Exact metrics do not match due to fallback',
                    'Document lengths are highly variant'
                ]
            };
        }
        logger_1.logger.info(`[DocumentPipeline] Comparison complete!`);
        return result;
    }
    catch (error) {
        logger_1.logger.error(`[DocumentPipeline] Failed to compare documents`, error);
        throw error;
    }
});
