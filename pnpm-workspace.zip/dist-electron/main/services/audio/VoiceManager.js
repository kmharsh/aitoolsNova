"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VoiceManager = void 0;
const logger_1 = require("../logger");
class VoiceManager {
    constructor(stt, tts, orchestrator) {
        // Audio state
        this.isListening = false;
        this.stt = stt;
        this.tts = tts;
        this._orchestrator = orchestrator;
    }
    async processIncomingAudio(audioBuffer, window) {
        if (this.isListening) {
            logger_1.logger.warn('VoiceManager is already processing a request. Dropping audio frame.');
            return;
        }
        this.isListening = true;
        window.webContents.send('nova:state', { intent: 'Processing Voice...', state: 'THINKING' });
        try {
            // 1. Transcribe Audio
            logger_1.logger.info('VoiceManager: Transcribing audio...');
            const transcript = await this.stt.transcribe(audioBuffer);
            logger_1.logger.info(`VoiceManager: Transcript -> "${transcript}"`);
            window.webContents.send('nova:state', { intent: `Executing: ${transcript}`, state: 'EXECUTING' });
            // 2. Route to Agent Orchestrator
            // The orchestrator handles planning and tool execution.
            // We trigger the intent processing natively here.
            this._orchestrator.processIntent(transcript);
            const resultText = `I am processing your command: ${transcript}`;
            // 3. Synthesize Response
            window.webContents.send('nova:state', { intent: 'Synthesizing speech...', state: 'COMPLETED' });
            const audioResponse = await this.tts.synthesize(resultText);
            // 4. Send back to Renderer to play
            window.webContents.send('nova:audio:response', {
                buffer: audioResponse,
                text: resultText
            });
        }
        catch (err) {
            logger_1.logger.error(`VoiceManager Error: ${err}`);
            window.webContents.send('nova:state', { intent: 'Error processing voice.', state: 'ERROR' });
        }
        finally {
            this.isListening = false;
            setTimeout(() => {
                window.webContents.send('nova:state', { intent: 'Awaiting instruction...', state: 'IDLE' });
            }, 5000); // return to idle after 5 seconds
        }
    }
}
exports.VoiceManager = VoiceManager;
