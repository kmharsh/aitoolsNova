"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BrowserAgent = void 0;
const playwright_1 = require("playwright");
class BrowserAgent {
    constructor(downloadManager) {
        this.downloadManager = downloadManager;
        this.browser = null;
        this.context = null;
        this.page = null;
    }
    async init() {
        if (!this.browser) {
            // For agent use, headless is preferred, but for visual debugging we can turn it off
            this.browser = await playwright_1.chromium.launch({ headless: true });
            this.context = await this.browser.newContext({
                acceptDownloads: true,
                userAgent: 'NOVA Agent / 1.0 (Automated System)'
            });
            this.page = await this.context.newPage();
            // Hook all download events natively to our secure DownloadManager
            this.page.on('download', async (download) => {
                await this.downloadManager.handlePlaywrightDownload(download);
            });
        }
    }
    async getPage() {
        if (!this.page) {
            await this.init();
        }
        return this.page;
    }
    async close() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
            this.context = null;
            this.page = null;
        }
    }
}
exports.BrowserAgent = BrowserAgent;
// Note: To make this a singleton for tools to use, we'd export an instance.
// But we need the DownloadManager configured. We'll set that up next.
