"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskPlanner = void 0;
const schemas_1 = require("../../../shared/schemas");
class TaskPlanner {
    constructor(aiProvider) {
        this.aiProvider = aiProvider;
    }
    async planTask(userInput) {
        // The prompt forces the LLM to output JSON matching the TaskSchema
        const prompt = `
      You are NOVA, a futuristic AI OS agent.
      User request: "${userInput}"
      
      Create an execution plan. Output strictly in JSON format matching this schema:
      {
        "id": "string",
        "intent": "string",
        "goal": "string",
        "steps": [{ "id": "string", "description": "string", "tool": "string", "args": {}, "status": "PENDING" }],
        "tools": ["string"],
        "riskLevel": "LOW|MEDIUM|HIGH",
        "requiresConfirmation": boolean,
        "status": "PLANNING"
      }
    `;
        // The provider automatically validates against TaskSchema
        const plan = await this.aiProvider.generateStructured(prompt, schemas_1.TaskSchema);
        return plan;
    }
}
exports.TaskPlanner = TaskPlanner;
