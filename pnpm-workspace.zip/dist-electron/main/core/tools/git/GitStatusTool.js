"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitStatusTool = void 0;
const BaseTool_1 = require("../BaseTool");
const zod_1 = require("zod");
const child_process_1 = require("child_process");
const util_1 = require("util");
const PathValidator_1 = require("../../security/PathValidator");
const execAsync = (0, util_1.promisify)(child_process_1.exec);
class GitStatusTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'git.status';
        this.description = 'Gets the current git status of the repository.';
        this.inputSchema = zod_1.z.object({
            repoPath: zod_1.z.string().describe('Absolute path to the repository root.')
        });
        this.outputSchema = zod_1.z.any();
        this.riskLevel = 'LOW';
        this.requiresPermission = false;
        this.timeoutMs = 15000;
    }
    async execute(input, _context) {
        try {
            PathValidator_1.pathValidator.validate(input.repoPath);
        }
        catch (e) {
            throw new Error(`Access Denied.`);
        }
        try {
            const { stdout } = await execAsync('git status --short', { cwd: input.repoPath });
            return { status: stdout.trim() || 'Working tree clean' };
        }
        catch (err) {
            throw new Error(`Git error: ${err.message}`);
        }
    }
}
exports.GitStatusTool = GitStatusTool;
