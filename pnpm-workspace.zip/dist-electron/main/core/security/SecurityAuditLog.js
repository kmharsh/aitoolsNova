"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecurityAuditLog = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const electron_1 = require("electron");
class SecurityAuditLog {
    static getLogPath() {
        // Write securely to userData, avoiding project directory tampering
        return path.join(electron_1.app.getPath('userData'), 'nova_security_audit.log');
    }
    static async logAction(agentName, toolName, riskLevel, payload, success) {
        const timestamp = new Date().toISOString();
        const statusStr = success ? 'SUCCESS' : 'DENIED/FAILED';
        const logEntry = `[${timestamp}] [AGENT:${agentName}] [TOOL:${toolName}] [RISK:${riskLevel}] [STATUS:${statusStr}] PAYLOAD:${JSON.stringify(payload)}\n`;
        try {
            await fs.promises.appendFile(this.getLogPath(), logEntry, 'utf8');
        }
        catch (e) {
            // In a hardened system, failure to audit might crash the app, 
            // but we will silently absorb for this MVP to avoid crashing user machines.
            console.error('CRITICAL: Failed to write to Security Audit Log');
        }
    }
}
exports.SecurityAuditLog = SecurityAuditLog;
