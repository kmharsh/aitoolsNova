"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitCommitTool = void 0;
const BaseTool_1 = require("../BaseTool");
const zod_1 = require("zod");
const child_process_1 = require("child_process");
const util_1 = require("util");
const PathValidator_1 = require("../../security/PathValidator");
const logger_1 = require("../../../services/logger");
const execAsync = (0, util_1.promisify)(child_process_1.exec);
class GitCommitTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'git.commit';
        this.description = 'Commits all tracked changes to git. Requires explicit user confirmation.';
        this.inputSchema = zod_1.z.object({
            repoPath: zod_1.z.string().describe('Absolute path to the repository root.'),
            message: zod_1.z.string().describe('Commit message.')
        });
        this.outputSchema = zod_1.z.any();
        this.riskLevel = 'HIGH';
        this.requiresPermission = true;
        this.timeoutMs = 30000;
    }
    async execute(input, _context) {
        try {
            PathValidator_1.pathValidator.validate(input.repoPath);
        }
        catch (e) {
            throw new Error(`Access Denied.`);
        }
        try {
            logger_1.logger.info(`[GitCommitTool] Staging and Committing changes in ${input.repoPath}`);
            await execAsync('git add .', { cwd: input.repoPath });
            const { stdout } = await execAsync(`git commit -m "${input.message.replace(/"/g, '\\"')}"`, { cwd: input.repoPath });
            return { success: true, stdout };
        }
        catch (err) {
            throw new Error(`Git commit failed: ${err.message}`);
        }
    }
}
exports.GitCommitTool = GitCommitTool;
