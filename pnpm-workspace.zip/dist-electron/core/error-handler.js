"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppError = void 0;
exports.handleError = handleError;
const logger_1 = require("../services/logger");
class AppError extends Error {
    constructor(message, isOperational = true) {
        super(message);
        Object.setPrototypeOf(this, new.target.prototype);
        this.isOperational = isOperational;
        Error.captureStackTrace(this);
    }
}
exports.AppError = AppError;
function handleError(error) {
    logger_1.logger.error('Unhandled Error', error);
    // Optionally notify renderer process if needed
}
process.on('uncaughtException', (err) => {
    handleError(err);
});
process.on('unhandledRejection', (reason) => {
    handleError(reason instanceof Error ? reason : new Error(String(reason)));
});
