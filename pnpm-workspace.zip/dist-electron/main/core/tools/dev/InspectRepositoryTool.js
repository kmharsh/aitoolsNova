"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.InspectRepositoryTool = void 0;
const BaseTool_1 = require("../BaseTool");
const zod_1 = require("zod");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const PathValidator_1 = require("../../security/PathValidator");
class InspectRepositoryTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'developer.inspectRepository';
        this.description = 'Inspects the structure and package.json of a repository.';
        this.inputSchema = zod_1.z.object({
            repoPath: zod_1.z.string().describe('Absolute path to the repository root.')
        });
        this.outputSchema = zod_1.z.any();
        this.riskLevel = 'LOW';
        this.requiresPermission = false;
        this.timeoutMs = 15000;
    }
    async execute(input, _context) {
        try {
            PathValidator_1.pathValidator.validate(input.repoPath);
        }
        catch (e) {
            throw new Error(`Access Denied: Cannot inspect path ${input.repoPath}`);
        }
        const result = { files: [] };
        try {
            const dirContents = await fs.promises.readdir(input.repoPath, { withFileTypes: true });
            result.files = dirContents.map(d => ({ name: d.name, isDirectory: d.isDirectory() }));
            const packageJsonPath = path.join(input.repoPath, 'package.json');
            if (fs.existsSync(packageJsonPath)) {
                const pkg = JSON.parse(await fs.promises.readFile(packageJsonPath, 'utf8'));
                result.dependencies = pkg.dependencies || {};
                result.devDependencies = pkg.devDependencies || {};
                result.scripts = pkg.scripts || {};
            }
            return result;
        }
        catch (err) {
            throw new Error(`Failed to inspect repository: ${err.message}`);
        }
    }
}
exports.InspectRepositoryTool = InspectRepositoryTool;
