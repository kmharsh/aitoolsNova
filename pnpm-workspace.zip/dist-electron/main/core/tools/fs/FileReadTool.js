"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileReadTool = void 0;
const zod_1 = require("zod");
const BaseTool_1 = require("../BaseTool");
const fs_1 = require("fs");
const PathValidator_1 = require("../../security/PathValidator");
const InputSchema = zod_1.z.object({
    filePath: zod_1.z.string().describe('The absolute or relative path to the file to read'),
    encoding: zod_1.z.enum(['utf8', 'base64', 'hex']).optional()
});
const OutputSchema = zod_1.z.object({
    content: zod_1.z.string(),
    size: zod_1.z.number()
});
class FileReadTool extends BaseTool_1.BaseTool {
    constructor() {
        super(...arguments);
        this.name = 'filesystem.read';
        this.description = 'Reads the contents of a file securely.';
        this.inputSchema = InputSchema;
        this.outputSchema = OutputSchema;
        this.riskLevel = 'LOW';
        this.requiresPermission = false;
        this.timeoutMs = 5000;
    }
    async execute(input, context) {
        context.emitActivity(`Reading file: ${input.filePath}`);
        const resolvedPath = PathValidator_1.pathValidator.validate(input.filePath);
        const stats = await fs_1.promises.stat(resolvedPath);
        if (!stats.isFile()) {
            throw new Error(`Target is not a file: ${resolvedPath}`);
        }
        const buffer = await fs_1.promises.readFile(resolvedPath);
        return {
            content: buffer.toString((input.encoding || 'utf8')),
            size: stats.size
        };
    }
}
exports.FileReadTool = FileReadTool;
