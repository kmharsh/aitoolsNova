"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OCRProcessor = void 0;
const tesseract_js_1 = require("tesseract.js");
const logger_1 = require("../logger");
class OCRProcessor {
    static async extractText(imagePath) {
        logger_1.logger.info(`[OCRProcessor] Initializing OCR for ${imagePath}`);
        try {
            const worker = await (0, tesseract_js_1.createWorker)('eng');
            const ret = await worker.recognize(imagePath);
            await worker.terminate();
            return ret.data.text;
        }
        catch (err) {
            logger_1.logger.error(`[OCRProcessor] OCR Failed: ${err.message}`);
            throw new Error(`Failed to extract text from image: ${err.message}`);
        }
    }
}
exports.OCRProcessor = OCRProcessor;
