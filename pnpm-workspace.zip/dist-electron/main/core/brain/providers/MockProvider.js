"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MockProvider = void 0;
const logger_1 = require("../../../services/logger");
class MockProvider {
    async generateResponse(_prompt, _systemPrompt) {
        logger_1.logger.info(`[MockProvider] Generating response for: ${_prompt.slice(0, 20)}...`);
        return new Promise(resolve => setTimeout(() => resolve("This is a mock response."), 1000));
    }
    async *streamResponse(_prompt) {
        yield "This ";
        yield "is ";
        yield "a ";
        yield "mock ";
        yield "stream.";
    }
    async generateStructured(_prompt, schema) {
        logger_1.logger.info(`[MockProvider] Generating structured output...`);
        // Simulate LLM parsing time
        await new Promise(resolve => setTimeout(resolve, 1500));
        // Hardcode a mock task structure that passes our Zod TaskSchema for testing
        const mockData = {
            id: `task_${Date.now()}`,
            intent: 'OS_CONTROL',
            goal: 'Open the user documents folder',
            steps: [
                {
                    id: `step_1`,
                    description: 'Search for Documents directory',
                    tool: 'fs_search',
                    args: { query: 'Documents' },
                    status: 'PENDING'
                },
                {
                    id: `step_2`,
                    description: 'Open the directory in Explorer',
                    tool: 'os_exec',
                    args: { command: 'explorer %USERPROFILE%\\Documents' },
                    status: 'PENDING'
                }
            ],
            tools: ['fs_search', 'os_exec'],
            riskLevel: 'MEDIUM',
            requiresConfirmation: true,
            status: 'PLANNING'
        };
        // We cast to any and parse it to ensure it perfectly matches the requested schema
        return schema.parse(mockData);
    }
}
exports.MockProvider = MockProvider;
